from numpy import array
from numpy import argmax
from keras.utils import to_categorical
import pandas as pd
import numpy as np
from sklearn.preprocessing import OneHotEncoder
from sklearn.preprocessing import LabelEncoder

data = pd.read_excel("inputdata_waterquality.xlsx", encoding = "cp949")
data_col = list(data.columns)


'Preparation of input data'
###### input1 categorical data --> wier category
## wier onehot encoding
weir_name = np.array(data['weir'])
weir_name_list = np.unique(weir_name)
# wier to integer
label_encoder = LabelEncoder()
integer_encoded = label_encoder.fit_transform(weir_name)
print(integer_encoded)
# wier integer to onehot
onehot_encoded = to_categorical(integer_encoded)

##### input 2 numeric data --> water quality data
## water quality data
input_wqvs = np.array(data[['DO', 'BOD', 'COD', 'SS', 'T.coli', 'TN', 'TP']])
input_wqvs = np.log(input_wqvs)

'Preparation of output data'
output = np.array(data['cyano_t1']).reshape(-1,1)
from sklearn.preprocessing import MinMaxScaler
scaler = MinMaxScaler()
scaler.fit(output)
output = scaler.transform(output)


'Split Train and Test data set'
from sklearn.model_selection import train_test_split
input_wqvs_train, input_wqvs_test, output_1_train, output_1_test = train_test_split(input_wqvs, output, test_size = 0.3, random_state =42)
onehot_encoded_train, onehot_encoded_test, output_1_train, output_1_test = train_test_split(onehot_encoded, output, test_size = 0.3, random_state =42)


'Setting Model Structure'
from keras.utils import plot_model
from keras.models import Model
from keras.layers import Input
from keras.layers import Dense
from keras.layers.merge import concatenate
import matplotlib.pyplot as plt

# WQVs way 7
visible1 = Input(shape = (7, ))
interp1 = Dense(10, activation = 'relu')(visible1)
interp2 = Dense(20, activation = 'relu')(interp1)
interp3 = Dense(10, activation = 'relu')(interp2)

# Weir way 16
visible2 = Input(shape = (16, ))
interp4 = Dense(20, activation = 'relu')(visible2)
interp5 = Dense(40, activation = 'relu')(interp4)
interp6 = Dense(20, activation = 'relu')(interp5)

merge = concatenate([interp3, interp6])

hidden1 = Dense(20, activation =  'relu')(merge)
hidden2 = Dense(10, activation = 'relu')(hidden1)
output = Dense(1, activation = 'relu')(hidden2)

model_water = Model(inputs = [visible1, visible2], outputs = output)
print(model_water.summary())
plot_model(model_water, to_file = 'chla_prediction.png')

from keras import backend as K
def root_mean_squared_error(y_true, y_pred):
        return K.sqrt(K.mean(K.square(y_pred - y_true))) 


import tensorflow as tf
from keras import optimizers
import keras as keras
keras.optimizers.Adam(lr=0.01, beta_1=0.9, beta_2=0.999, epsilon=None, decay=0.0, amsgrad=False)
model_water.compile(loss = root_mean_squared_error,optimizer = "adam")
hist = model_water.fit(x = [input_wqvs_train, onehot_encoded_train], y = output_1_train, epochs = 50, batch_size = 100)
print(hist.history['loss'])

import matplotlib.pyplot as plt
plt.plot(hist.history['loss'])
plt.show()

