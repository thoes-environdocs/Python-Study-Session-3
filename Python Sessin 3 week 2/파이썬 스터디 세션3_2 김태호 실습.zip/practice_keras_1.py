'''
Keras Sequential Models
'''

from keras.models import Sequential
from keras.layers import Dense

model = Sequential()
model.add(Dense(2, input_dim = 1))
model.add(Dense(1))

# it is not straightforward to define models that may have multiple
# different input sources, produce multiple output destinations or models
# that re-use layers.

'''
Keras Functional Models
'''
# get more flexible for defining models.
# specifically allows your to define multiple input or output models
# as well as models that share layers.

#1. Defining Input
from keras.layers import Input
from keras.layers import Dense
from keras.utils import plot_model
from keras.models import Model
import matplotlib.pyplot as plt

visible = Input(shape = (2, ))
hidden1 = Dense(2, activation = 'relu')(visible)
hidden2 = Dense(10, activation = 'relu')(hidden1)
hidden3 = Dense(10, activation = 'relu')(hidden2)
output = Dense(1, activation = 'sigmoid')(hidden3)
model_nn = Model(inputs = visible, outputs = output)

import os
os.environ["PATH"] += os.pathsep + 'C:\\Program Files (x86)\\Graphviz2.38\\bin'
print(model_nn.summary())
plot_model(model_nn, to_file = 'first.png')
plt.show()

#2. Convolutional Neural Network
from keras.layers import Flatten
from keras.layers.convolutional import Conv2D
from keras.layers.pooling import MaxPooling2D
visible = Input(shape = (64, 64, 1))
conv1 = Conv2D(32, kernel_size = 4, activation = 'relu')(visible)
pool1 = MaxPooling2D(pool_size = (2, 2))(conv1)
conv2 = Conv2D(16, kernel_size = 4, activation = 'relu')(pool1)
pool2 = MaxPooling2D(pool_size = (2, 2))(conv2)
flat = Flatten()(pool2)
hidden1 = Dense(10, activation = 'relu')(flat)
output = Dense(1, activation = 'sigmoid')(hidden1)
model_cnn = Model(inputs = visible, outputs = output)
print(model_cnn.summary())
plot_model(model_cnn, to_file = 'cnn_1.png')


#3. Recurrent Neural Network
from keras.utils import plot_model
from keras.layers.recurrent import LSTM
visible = Input(shape = (100, 1))
hidden1 = LSTM(10)(visible)
hidden2 = Dense(10, activation = 'relu')(hidden1)
output = Dense(1, activation = 'sigmoid')(hidden2)
model_lstm = Model(inputs = visible, outputs = output)
print(model_lstm.summary())
plot_model(model, to_file = 'lstm_1.png')


#4. Shared Layers Model
# there may be multiple different feature extraction layers from an input,
# or multiple laters used to interpret the output from a feature extraction layer
from keras.utils import plot_model
from keras.models import Model
from keras.layers import Input
from keras.layers import Dense
from keras.layers import Flatten
from keras.layers.convolutional import Conv2D
from keras.layers.pooling import MaxPooling2D
from keras.layers.merge import concatenate
# input layer
visible = Input(shape = (64, 64, 1))
# first feature extractor
conv1 = Conv2D(32, kernel_size = 4, activation = 'relu')(visible)
pool1 = MaxPooling2D(pool_size = (2, 2))(conv1)
flat1 = Flatten()(pool1)
# second feature extractor
conv2 = Conv2D(16, kernel_size = 8, activation = 'relu')(visible)
pool2 = MaxPooling2D(pool_size = (2, 2))(conv2)
flat2 = Flatten()(pool2)
# merge feature extractors
merge = concatenate([flat1, flat2])
# interpretation layer
hidden1 = Dense(10, activation = 'relu')(merge)
# prediction output
output = Dense(1, activation = 'sigmoid')(hidden1)
model_merge = Model(inputs = visible, outputs = output)

print(model_merge.summary())
plot_model(model_merge, to_file = 'shared_1.png')


#5. Shared Feature Extraction Layer
from keras.layers.recurrent import LSTM
from keras.layers.merge import concatenate
visible = Input(shape = (100, 1))
extract1 = LSTM(10)(visible)
interp1 = Dense(10, activation = 'relu')(extract1)
interp11 = Dense(10, activation = 'relu')(extract1)
interp12 = Dense(20, activation = 'relu')(interp11)
interp13 = Dense(10, activation = 'relu')(interp12)

merge = concatenate([interp1, interp13])
output = Dense(1, activation = 'sigmoid')(merge)
model_merge2 = Model(inputs = visible, outputs = output)

print(model_merge2.summary())
plot_model(model_merge2, to_file = 'merge_2.png')

#6. Multiple input and output models
from keras.utils import plot_model
from keras.models import Model
from keras.layers import Input
from keras.layers import Dense
from keras.layers import Flatten
from keras.layers.convolutional import Conv2D
from keras.layers.pooling import MaxPooling2D
from keras.layers.merge import concatenate

visible1 = Input(shape = (64, 64, 1))
conv11 = Conv2D(32, kernel_size = 4, activation = 'relu')(visible1)
pool11 = MaxPooling2D(pool_size = (2, 2))(conv11)
conv12 = Conv2D(16, kernel_size = 4, activation = 'relu')(pool11)
pool12 = MaxPooling2D(pool_size = (2, 2))(conv12)
flat1 = Flatten()(pool12)

visible2 = Input(shape = (10, ))
interp1 = Dense(20, activation = 'relu')(visible2)
interp2 = Dense(10, activation = 'relu')(interp1)
interp3 = Dense(5, activation = 'relu')(interp2)

merge = concatenate([flat1, interp3])

hidden1 = Dense(10, activation =  'relu')(merge)
hidden2 = Dense(10, activation = 'relu')(hidden1)
output = Dense(1, activation = 'sigmoid')(hidden2)
model_cloud = Model(inputs = [visible1, visible2], outputs = output)

print(model_cloud.summary())
plot_model(model_cloud, to_file = 'model_cloud.png')






