##Python 3.6.5 (v3.6.5:f59c0932b4, Mar 28 2018, 05:52:31) 
##[GCC 4.2.1 Compatible Apple LLVM 6.0 (clang-600.0.57)] on darwin
##Type "copyright", "credits" or "license()" for more information.
##>>> import os
##>>> os.getcwd()
##'/Users/jay/Documents'
##>>> os.chdir('/Users/jay/Documents/project_Python_01')
##>>> os.getcwd()
##'/Users/jay/Documents/project_Python_01'
##>>> 
import pandas as pd
import numpy as np

#패키지를 먼저 실행 후, 데이터 불러와야 오류가 발생안함

df=pd.read_excel("02. sales-funnel.xlsx")
df.head()
print(df.head())

pd.pivot_table(df,index=["Name"])
print(pd.pivot_table(df,index=["Name"]))
