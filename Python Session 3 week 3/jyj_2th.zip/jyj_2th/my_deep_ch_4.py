##Python 3.6.5 (v3.6.5:f59c0932b4, Mar 28 2018, 05:52:31) 
##[GCC 4.2.1 Compatible Apple LLVM 6.0 (clang-600.0.57)] on darwin
##Type "copyright", "credits" or "license()" for more information.
##>>> import os
##>>> os.getcwd()
##'/Users/jay/Documents'
##>>> os.chdir('/Users/jay/Documents/deeplearning_master')
##>>> os.getcwd()
##'/Users/jay/Documents/deeplearning_master'

import tensorflow as tf
##1> x,y의 데이터 값
data=[[2,81],[4,93],[6,91],[8,97]]
x_data=[x_row[0] for x_row in data]
y_data=[y_row[1] for y_row in data]


##2> 기울기 a와 y절편 b의 값을 임의로 정한다.
#단, 기울기의 범위는 0~10사이이며, y절편은 0~100사이에서 변하게 한다.
a=tf.Variable(tf.random.uniform([1],0,10,dtype=tf.float64,seed=0))
b=tf.Variable(tf.random.uniform([1],0,100,dtype=tf.float64,seed=0))

#y에 대한 일차 방정식 ax+b의 식을 세운다.
y=a*x_data+b

##3>텐서플로우 RMSE함수
rmse=tf.sqrt(tf.reduce_mean(tf.square(y-y_data)))

#학습률값
learning_rate=0.1

#RMSE값을 최소로 하는 값 찾기
gradient_decent=tf.compat.v1.train.GradientDescentOptimizer(learning_rate).minimize(rmse)

##4>텐서플로우를 이용한 학습
with tf.compat.v1.Session() as sess:
#변수 초기화    
    sess.run(tf.compat.v1.global_variables_initializer())
#2001번 실행(0번째를 포함하므로)
    for step in range(2001):
        sess.run(gradient_decent)
#100번마다 결과 출력
        if step % 100 == 0:
            print("Epoch: %.f, RMSE = %.04f, 기울기 a = %.4f, y 절편 b = %.4f" % (step,sess.run(rmse),sess.run(a),sess.run(b)))
#에포크(Epoch)는 입력값에 대해 몇번이나 반복하여 실험했는지를 나타냄, %.4f는 자리수 보여주는 것
