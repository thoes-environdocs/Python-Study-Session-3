####>>> import os
####>>> os.getcwd()
####'/Users/jay/Documents'
####>>> os.chdir('/Users/jay/Documents/project_Python_01')
####>>> os.getcwd()
####'/Users/jay/Documents/project_Python_01'
####>>>
#googlemaps를 이용해서 주소/경위도_좌표얻기
import numpy as np
import pandas as pd

crime_anal_police=pd.read_csv('02. crime_in_Seoul.csv',thousands=',',encoding='euc-kr')
crime_anal_police.head()
print(crime_anal_police.head())

import googlemaps

gmaps_key="?????????????"
gmaps = googlemaps.Client(key=gmaps_key)

gmaps.geocode('서울중부경찰서', language='ko')
print(gmaps.geocode('서울중부경찰서', language='ko'))

#경찰서이름에 ‘서울~경찰서’ 형태로 변경
station_name=[]

for name in crime_anal_police['관서명']:
    station_name.append('서울'+str(name[:-1])+'경찰서')
station_name

print(station_name)

#주소출력
station_address=[]
station_lat=[]
station_lng=[]

for name in station_name:
    tmp=gmaps.geocode(name,language='ko')
    station_address.append(tmp[0].get("formatted_address"))

    tmp_loc=tmp[0].get("geometry")
    station_lat.append(tmp_loc['location']['lat'])
    station_lng.append(tmp_loc['location']['lng'])
    print(name+'-->'+tmp[0].get("formatted_address"))

print(station_address)
print(station_lat)
print(station_lng)

gu_name=[]

for name in station_address:
    tmp=name.split()

    tmp_gu=[gu for gu in tmp if gu[-1]=='구'][0]

    gu_name.append(tmp_gu)

crime_anal_police['구별']=gu_name
crime_anal_police.head()
print(crime_anal_police)

crime_anal_police[crime_anal_police['관서명']=='금천서']
print(crime_anal_police[crime_anal_police['관서명']=='금천서'])

crime_anal_police.to_csv('crime_in_Seoul_include_gu_name.csv',sep=',',encoding='utf-8')

crime_anal_raw=pd.read_csv('crime_in_Seoul_include_gu_name.csv',encoding='utf-8')
crime_anal_raw.head()
print(crime_anal_raw.head())

crime_anal_raw=pd.read_csv('crime_in_Seoul_include_gu_name.csv',encoding='utf-8',index_col=0)
crime_anal=pd.pivot_table(crime_anal_raw,index='구별',aggfunc=np.sum)
crime_anal.head()
print(crime_anal.head())

crime_anal['강간검거율']=crime_anal['강간 검거']/crime_anal['강간 발생']*100
crime_anal['강도검거율']=crime_anal['강도 검거']/crime_anal['강도 발생']*100
crime_anal['살인검거율']=crime_anal['살인 검거']/crime_anal['살인 발생']*100
crime_anal['절도검거율']=crime_anal['절도 검거']/crime_anal['절도 발생']*100
crime_anal['폭력검거율']=crime_anal['폭력 검거']/crime_anal['폭력 발생']*100

del crime_anal['강간 검거']
del crime_anal['강도 검거']
del crime_anal['살인 검거']
del crime_anal['절도 검거']
del crime_anal['폭력 검거']

crime_anal.head()
print(crime_anal.head())

con_list=['강간검거율','강도검거율','살인검거율','절도검거율','폭력검거율']
for column in con_list:
    crime_anal.loc[crime_anal[column]>100,column]=100

crime_anal.head()
print(crime_anal.head())

crime_anal.rename(columns={'강간 발생':'강간',
                           '강도 발생':'강도',
                           '살인 발생':'살인',
                           '절도 발생':'절도',
                           '폭력 발생':'폭력'},inplace=True)
crime_anal.head()
print(crime_anal.head())

from sklearn import preprocessing

col=['강간','강도','살인','절도','폭력']

x=crime_anal[col].values
min_max_scaler=preprocessing.MinMaxScaler()

x_scaled=min_max_scaler.fit_transform(x.astype(float))
crime_anal_norm=pd.DataFrame(x_scaled,columns=col,index=crime_anal.index)

col2=['강간검거율','강도검거율','살인검거율','절도검거율','폭력검거율']
crime_anal_norm[col2]=crime_anal[col2]
crime_anal_norm.head()
print(crime_anal_norm.head())

result_CCTV=pd.read_csv('01. CCTV_result.csv',encoding='UTF-8',index_col='구별')
crime_anal_norm[['인구수','CCTV']]=result_CCTV[['인구수','소계']]
crime_anal_norm.head()
print(crime_anal_norm.head())

col=['강간','강도','살인','절도','폭력']
crime_anal_norm['범죄']=np.sum(crime_anal_norm[col],axis=1)
crime_anal_norm.head()

col=['강간검거율','강도검거율','살인검거율','절도검거율','폭력검거율']
crime_anal_norm['검거']=np.sum(crime_anal_norm[col],axis=1)
crime_anal_norm.head()
print(crime_anal_norm.head())

crime_anal_norm.columns
print(crime_anal_norm.columns)

#범죄 데이터 시각화 하기

import matplotlib.pyplot as plt
import seaborn as sns

import platform

from matplotlib import font_manager, rc
plt.rcParams['axes.unicode_minus'] = False

if platform.system() == 'Darwin':
    rc('font', family='AppleGothic')
elif platform.system() == 'Windows':
    path = "c:/Windows/Fonts/malgun.ttf"
    font_name = font_manager.FontProperties(fname=path).get_name()
    rc('font', family=font_name)
else:
    print('Unknown system... sorry~~~~')

##sns.pairplot(crime_anal_norm,vars=['강도','살인','폭력'],kind='reg',size=3)
##plt.show()

##sns.pairplot(crime_anal_norm,x_vars=['인구수','CCTV'],y_vars=['살인','강도'],kind='reg',size=3)
##plt.show()

##sns.pairplot(crime_anal_norm,x_vars=['인구수','CCTV'],y_vars=['살인검거율','폭력검거율'],kind='reg',size=3)
##plt.show()

tmp_max=crime_anal_norm['검거'].max()
crime_anal_norm['검거']=crime_anal_norm['검거']/tmp_max*100
crime_anal_norm_sort=crime_anal_norm.sort_values(by='검거',ascending=False)
crime_anal_norm_sort.head()

##
##target_col=['강간검거율', '강도검거율', '살인검거율', '절도검거율','폭력검거율']
##crime_anal_norm_sort=crime_anal_norm.sort_values(by='검거',ascending=False)
##
##plt.figure(figsize=(15,15))
##sns.heatmap(crime_anal_norm_sort[target_col],annot=True,fmt='f',linewidths=.5)
##plt.title('범죄 검거 비율(정규화된 검거의 합으로 정렬)')
##plt.show()


##target_col=['강간','강도','살인','절도','폭력','범죄']
##
##crime_anal_norm['범죄']=crime_anal_norm['범죄']/5
##crime_anal_norm_sort=crime_anal_norm.sort_values(by='범죄',ascending=False)
##
##plt.figure(figsize=(10,10))
##sns.heatmap(crime_anal_norm_sort[target_col],annot=True,fmt='f',linewidth=.5)
##plt.title('범죄비율(정규화된 발생 건수로 정렬)')
##plt.show()

crime_anal_norm.to_csv('02. crime_in_Seoul_final_01.csv',sep=',',encoding='utf-8')









































































