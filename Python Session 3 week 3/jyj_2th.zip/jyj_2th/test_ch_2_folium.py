##Python 3.6.5 (v3.6.5:f59c0932b4, Mar 28 2018, 05:52:31) 
##[GCC 4.2.1 Compatible Apple LLVM 6.0 (clang-600.0.57)] on darwin
##Type "copyright", "credits" or "license()" for more information.
##>>> import os
##>>> os.getcwd()
##'/Users/jay/Documents'
##>>> os.chdir('/Users/jay/Documents/project_Python_01')
##>>> os.getcwd()
##'/Users/jay/Documents/project_Python_01'
##>>> 
#import folium

##map_osm=folium.Map(location=[45.5236, -122.6750])
##map_osm.save('map_osm_01.html')
#저장하고, 크롬브라우저로 열어야 지도확인 가능

##stamen=folium.Map(location=[45.5236, -122.6750],zoom_start=13)
##stamen.save('stame_01.html')

##stamen=folium.Map(location=[45.5236, -122.6750],tiles='Stamen Toner',zoom_start=13)
##stamen.save('stame_02.html')
#tiles='Stamen Toner’흑백지도 옵션

##map_4=folium.Map(location=[45.5236, -122.6750],tiles='Stamen Toner',zoom_start=13)
##folium.Marker([45.5244,-122.6699],popup='The Waterfront').add_to(map_4)
##folium.CircleMarker([45.5215,-122.6261],radius=50,popup='Laurelhurst Park',color='#3186cc',fill_color='#3186cc',).add_to(map_4)
##map_4.save('map_4.html')
      
##import folium
##import pandas as pd
##
##state_unemployment='02. folium_US_Unemployment_Oct2012.csv'
##state_data=pd.read_csv(state_unemployment)
##state_data.head()
##print(state_data.head())
##
##state_geo='02. folium_us-states.json'
##
##map=folium.Map(location=[40,-98],zoom_start=4)
##map.choropleth(geo_data=state_geo,data=state_data,
##               columns=['State','Unemployment'],
##               key_on='feature.id',fill_color='YlGn',
##               legend_name='Unemployment Rate(%)')
##map.save('map_em_5.html')


##import folium
##import pandas as pd
##import json
##
##geo_path='02. skorea_municipalities_geo_simple.json'
##geo_str=json.load(open(geo_path,encoding='utf-8'))
##
###print(geo_str)
##
##crime_anal_norm=pd.read_csv('02. crime_in_Seoul_final_01.csv',encoding='utf-8')
##crime_anal_norm.head(5)
#print(crime_anal_norm.head(5))
##
##map=folium.Map(location=[37.5502,126.982],zoom_start=11, tiles='Stamen Toner')
##folium.Choropleth(geo_data=geo_str,data=crime_anal_norm,
##                  columns=['구별','살인'],key_on='feature.id',fill_color='PuRd').add_to(map)
##map.save('map_seoul_12.html')


#https://python-visualization.github.io/folium/quickstart.html#Getting-Started

##map=folium.Map(location=[37.5502,126.982],zoom_start=11, tiles='Stamen Toner')
##folium.Choropleth(geo_data=geo_str,data=crime_anal_norm,
##                  columns=['구별','범죄'],key_on='feature.id',fill_color='PuRd').add_to(map)
##map.save('map_seoul_16.html')

##crime_anal_norm['tmp_crimial']=crime_anal_norm['살인']/crime_anal_norm['인구수']*1000000
##crime_anal_norm.head(5)
##(crime_anal_norm.head(5))

##crime_anal_norm.sort_values(by='tmp_crimial',ascending=False)
##print(crime_anal_norm.sort_values(by='tmp_crimial',ascending=False))

##crime_anal_norm[crime_anal_norm['구별']=='양천구']
##print(crime_anal_norm[crime_anal_norm['구별']=='양천구'])
#강서경찰서 임시청사가 양천구 신월동 임시 청사 위치


##map=folium.Map(location=[37.5502,126.982],zoom_start=11, tiles='Stamen Toner')
##folium.Choropleth(geo_data=geo_str,data=crime_anal_norm,
##                  columns=['구별','tmp_crimial'],key_on='feature.id',fill_color='PuRd').add_to(map)
##
##map.save('map_seoul_31.html')


#서울시 경찰서별 검거율과 구별 범죄 발생율을 동시에 시각화하기
import numpy as np
import pandas as pd

crime_anal_police=pd.read_csv('02. crime_in_Seoul.csv',thousands=',',encoding='euc-kr')
crime_anal_police.head()
print(crime_anal_police.head())

import googlemaps

gmaps_key="??????????"
gmaps = googlemaps.Client(key=gmaps_key)

gmaps.geocode('서울중부경찰서', language='ko')
print(gmaps.geocode('서울중부경찰서', language='ko'))

#경찰서이름에 ‘서울~경찰서’ 형태로 변경
station_name=[]

for name in crime_anal_police['관서명']:
    station_name.append('서울'+str(name[:-1])+'경찰서')
station_name

print(station_name)

#주소출력
station_address=[]
station_lat=[]
station_lng=[]

for name in station_name:
    tmp=gmaps.geocode(name,language='ko')
    station_address.append(tmp[0].get("formatted_address"))

    tmp_loc=tmp[0].get("geometry")
    station_lat.append(tmp_loc['location']['lat'])
    station_lng.append(tmp_loc['location']['lng'])
    print(name+'-->'+tmp[0].get("formatted_address"))

print(station_address)
print(station_lat)
print(station_lng)

gu_name=[]

for name in station_address:
    tmp=name.split()

    tmp_gu=[gu for gu in tmp if gu[-1]=='구'][0]

    gu_name.append(tmp_gu)

crime_anal_police['구별']=gu_name
crime_anal_police.head()
print(crime_anal_police)

crime_anal_police[crime_anal_police['관서명']=='금천서']
print(crime_anal_police[crime_anal_police['관서명']=='금천서'])

crime_anal_raw=pd.read_csv('crime_in_Seoul_include_gu_name.csv',encoding='utf-8')
crime_anal_raw.head()
print(crime_anal_raw.head())

import folium
import pandas as pd
import numpy as np
import json

geo_path='02. skorea_municipalities_geo_simple.json'
geo_str=json.load(open(geo_path,encoding='utf-8'))

crime_anal_raw['lat']=station_lat
crime_anal_raw['lng']=station_lng

col=['살인 검거','강도 검거','강간 검거','절도 검거','폭력 검거']
tmp=crime_anal_raw[col]/crime_anal_raw[col].max()

crime_anal_raw['검거']=np.sum(tmp,axis=1)
crime_anal_raw.head(5)
print(crime_anal_raw.head(5))

crime_anal_norm=pd.read_csv('02. crime_in_Seoul_final_01.csv',encoding='utf-8')
crime_anal_norm['tmp_crimial']=crime_anal_norm['살인']/crime_anal_norm['인구수']*1000000
crime_anal_norm.head(5)
print(crime_anal_norm.head(5))

##map=folium.Map(location=[37.5502,126.982],zoom_start=11)
##
##for n in crime_anal_raw.index:
##    folium.Marker([crime_anal_raw['lat'][n],crime_anal_raw['lng'][n]]).add_to(map)
##map
##map.save('map_seoul_41.html')

##map=folium.Map(location=[37.5502,126.982],zoom_start=11)
##
##for n in crime_anal_raw.index:
##    folium.CircleMarker([crime_anal_raw['lat'][n],crime_anal_raw['lng'][n]],
##                        radius=crime_anal_raw['검거'][n]*10,
##                        color='#3186cc',fill_color='#3186cc').add_to(map)
##map
##map.save('map_seoul_42.html')


map=folium.Map(location=[37.5502,126.982],zoom_start=11, tiles='Stamen Toner')
folium.Choropleth(geo_data=geo_str,data=crime_anal_norm,
                  columns=['구별','범죄'],key_on='feature.id',fill_color='PuRd').add_to(map)

for n in crime_anal_raw.index:
    folium.CircleMarker([crime_anal_raw['lat'][n],crime_anal_raw['lng'][n]],
                        radius=crime_anal_raw['검거'][n]*10,
                        color='#3186cc',fill_color='#3186cc').add_to(map)
map
map.save('map_seoul_44.html')






















