##Python 3.6.5 (v3.6.5:f59c0932b4, Mar 28 2018, 05:52:31) 
##[GCC 4.2.1 Compatible Apple LLVM 6.0 (clang-600.0.57)] on darwin
##Type "copyright", "credits" or "license()" for more information.
##>>> import os
##>>> os.getcwd()
##'/Users/jay/Documents'
##>>> os.chdir('/Users/jay/Documents/project_Python_01')
##>>> os.getcwd()
##'/Users/jay/Documents/project_Python_01'
##>>> 

from bs4 import BeautifulSoup

page=open('03. test_first.html','r').read()
soup=BeautifulSoup(page,'html.parser')
##print(soup.prettify())

##list(soup.children)
##print(list(soup.children))

html=list(soup.children)[2]
html
##print(html)

children=list(html.children)
##print(children)

list(html.children)[3]
print(list(html.children)[3])

soup.body
##print(soup.body)

##list(body.children)
##print(list(body.children))

